# JediSecX QuickTools

Suite of cybersecurity and OSINT tools by Jedi Security.

Includes:
- Mass Subdomain Enumerator
- URL Unshortener and Redirect Mapper
- Bulk File Metadata Extractor
- Hash Cracker (Dictionary Attack)
- Multi-AV + VirusTotal Scanner
